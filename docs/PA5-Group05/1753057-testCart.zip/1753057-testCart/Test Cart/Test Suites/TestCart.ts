<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>TestCart</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>b5607095-8912-413c-90b2-67d332507b48</testSuiteGuid>
   <testCaseLink>
      <guid>9ca955e5-2c62-4b48-a96b-cdfd04f55521</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TestEditCart</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>56270084-cb39-4a16-974c-5c2ea3701dae</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TestRemoveProduct</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
