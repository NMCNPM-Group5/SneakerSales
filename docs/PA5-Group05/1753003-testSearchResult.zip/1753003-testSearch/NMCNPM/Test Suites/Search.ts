<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Search</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>3eca703a-928c-46a2-a58b-7bfc9d567a8d</testSuiteGuid>
   <testCaseLink>
      <guid>8a841538-b8da-4f3d-be3e-8540540283db</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Size</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>43133acc-95fe-4349-b0cc-1d0bfa2d5a2b</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/Size</testDataId>
      </testDataLink>
      <variableLink>
         <testDataLinkId>43133acc-95fe-4349-b0cc-1d0bfa2d5a2b</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>size</value>
         <variableId>a5fc02f8-8087-49b8-9103-8894f20e00cf</variableId>
      </variableLink>
   </testCaseLink>
   <testCaseLink>
      <guid>0e871c66-a3c6-4de9-8e33-605102bf01de</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Brand</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>f23871ac-44f2-4cfb-bb10-635df8810fa5</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/Brand</testDataId>
      </testDataLink>
      <variableLink>
         <testDataLinkId>f23871ac-44f2-4cfb-bb10-635df8810fa5</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>brand</value>
         <variableId>bb24000e-dc3b-44c7-8683-1d6fe749acb9</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
